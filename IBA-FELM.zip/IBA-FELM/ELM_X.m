function [Fittness,OutputWeight] = ELM_X (Elm_Type, weight_bias, P, T, NumberofHiddenNeurons)
NumberofTrainingData=size(P,2);
NumberofInputNeurons=size(P,1);
Gain=1;
temp_weight_bias=reshape(weight_bias, NumberofHiddenNeurons, NumberofInputNeurons+1);
InputWeight=temp_weight_bias(:, 1:NumberofInputNeurons);
BiasofHiddenNeurons=temp_weight_bias(:,NumberofInputNeurons+1);
tempH=InputWeight*P;
ind=ones(1,NumberofTrainingData);
BiasMatrix=BiasofHiddenNeurons(:,ind);  %��ƫ�þ������䵽ÿ�У���tempHά����ͬ
tempH=tempH+BiasMatrix;
% clear BiasMatrix
H = 1 ./ (1 + exp(-Gain*tempH));
% clear tempH;
OutputWeight=pinv(H') * T';
Y=(H' * OutputWeight)';

 if Elm_Type==0
     Fittness=sqrt(mse(T - Y));            %   Calculate testing accuracy (RMSE) for regression case
 end
 
% if Elm_Type==1
% %%%%%%%%%% Calculate training & testing classification accuracy
%     MissClassificationRate_Training=0;
%     for i = 1 : size(TV.T,2)
%         [x, label_index_expected]=max(TV.T(:,i));
%         [x, label_index_actual]=max(TY(:,i));
%         if label_index_actual~=label_index_expected
%             MissClassificationRate_Training=MissClassificationRate_Training+1;
%            
%         end
%     end
%      Fittness=MissClassificationRate_Training/size(TV.T,2); 
%         else
%     Fittness=sqrt(mse(TV.T - TY));
% 
% end
% end
      
      
  

