clear all;
close all;
clc;
tic;
n=45;      % Population size, typically 10 to 25 初始种群个数
A=1;      % Loudness  (constant or decreasing) 最大脉冲音量
r0=0.001;      % Pulse rate (constant or decreasing) 最大脉冲率
% This frequency range determines the scalings 搜索脉冲频率范围
Qmin=0.3;         % Frequency minimum 
Qmax=0.8;         % Frequency maximum 
r = r0;

p=load('');%输入训练集数据
t2=load('');%输入训练集标签
p=mapminmax(p);
Ptrain=[p];
Ttrain=[t2];
NumberofInputNeurons=size(Ptrain,1);
NumberofHiddenNeurons=30;
%% In order to obtain better/more accurate results, N_iter should be increased to N_iter=2000 or more if necessary.
N_iter=40;       % Total number of function evaluations
% Dimension of the search variables
D=NumberofHiddenNeurons*(NumberofInputNeurons+1);
alpha = 1.2;
gamma = 0.9;
XVmin=-ones(1,D);
XVmax=ones(1,D);
% Initial arrays
Q=zeros(n,1);   % Frequency
v=zeros(n,D);   % Velocities
% Initialize the population/solutions
start_time_validation=cputime;
OutputWeight=cell(1,n);
bestweight=zeros(NumberofHiddenNeurons,1);
best=zeros(1,D);
Fittness=zeros(1,n);
Sol=zeros(n,D);
for i=1:n
  Sol(i,:)=XVmin + (XVmax - XVmin).*rand(1,D);
  [Fittness(i),OutputWeight{i}]=ELM_X(0,Sol(i,:),Ptrain,Ttrain,NumberofHiddenNeurons);
end
[fmin,w]=min(Fittness);%[最小值 坐标]
bestweight = OutputWeight{w};
best = Sol(w,:);
for i_ter=1:N_iter
    pt=sqrt(i_ter/N_iter-1);     
    S=get_cuckoos(Sol,best,XVmin,XVmax);%莱维飞行
    for i=1:n
       [Fittness11(i),OutputWeight11{i}]=ELM_X(0,S(i,:),Ptrain,Ttrain,NumberofHiddenNeurons);
    end
       [fmin11,w11]=min(Fittness11);%[最小值 坐标]
       best11 = S(w11,:);
    for i=1:n
        f1=((Qmin-Qmax)*i_ter/N_iter+Qmax)*rand;
        f2=((Qmax-Qmin)*i_ter/N_iter+Qmin)*rand;
        qqq=S(randperm(n,4),:);
        S(i,:)=best+f1*(qqq(1,:)-qqq(2,:))+f2*(qqq(3,:)-qqq(4,:));
        S(i,:)=best+f1*(qqq(1,:)-qqq(2,:))+f2*(qqq(3,:)-qqq(4,:))+S(i,:)*(1-exp(-(i_ter/N_iter).^6));
        if rand<pt
            S(i,:)=S(i,:)+randn*S(i,:);    
        end
    end 
    if rand>r
        for i=1:n
            S1(i,:)=XVmin+XVmax-S(i,:);
        end    
        SS=[S1;S];
        for i=1:2*n    
            [Fittness1(i),OutputWeight1]=ELM_X(0,SS(i,:),Ptrain,Ttrain,NumberofHiddenNeurons);
        end
        [Fittness1,aa]=sort(Fittness1);
        S=SS(aa(1:n),:);
        S=S+(2*rand-1)*A/n;     
    end
    Evaluate new solutions
    for i=1:n
        [Fnew,OutputWeight] = ELM_X(0,S(i,:),Ptrain,Ttrain,NumberofHiddenNeurons);
        if (Fnew<=Fittness(i)) && (rand < A)
            Sol(i,:)=S(i,:);
            Fittness(i)=Fnew;
            A = alpha * A;
            r = r0*(1-exp(-gamma*i_ter));
            r = r*((i_ter/0.6).^3);
        end
        if Fnew<=fmin
            best=S(i,:);
            fmin=Fnew;
            bestweight=OutputWeight;
        end
    end
    uuu(i_ter)=fmin;
end
End of the main bat algorithm and output/display can be added here.
end_time_validation=cputime;
TrainingTime=end_time_validation-start_time_validation

start_time_validation=cputime;
Beta = mean(abs(OutputWeight));
NumberInputNeurons=size(Ptrain, 1);
NumberofTrainingData=size(Ptrain, 2);
Gain=1;
temp_weight_bias=reshape(best, NumberofHiddenNeurons, NumberInputNeurons+1);
InputWeight=temp_weight_bias(:, 1:NumberInputNeurons);
BiasofHiddenNeurons=temp_weight_bias(:,NumberInputNeurons+1);
tempH=InputWeight*Ptrain;
ind=ones(1,NumberofTrainingData);
BiasMatrix=BiasofHiddenNeurons(:,ind);      %   Extend the bias matrix BiasofHiddenNeurons to match the demention of H
tempH=tempH+BiasMatrix;
H = 1 ./ (1 + exp(-Gain*tempH));
bestweight=pinv(H') * Ttrain';
Y=(H' * bestweight)';
ct1=load('');%输入标签
a=load('');%输入特征数据
a=mapminmax(a);
% % p1=zscore(a);%标准化
% % [P,princ,eigenvalue,t23]=pca(p1);%调用主成分分析函数
% % per=100*eigenvalue/sum(eigenvalue);%求主元贡献率
% % u=cumsum(per);%求出各个主成分的累计贡献率
% % zhu1=[princ(:,1)]';
% % zhu2=[princ(:,2)]';
ccc=[a];
ddd=[ct1];
NumberofTestingData=length(ct1);
tempH_test=InputWeight*ccc;
ind=ones(1,NumberofTestingData);
BiasMatrix=BiasofHiddenNeurons(:,ind); 
tempH_test=tempH_test + BiasMatrix;
H_test=1./(1 + exp(-Gain*tempH_test));
HH=pinv(H_test');
bestweight=HH * ddd';
TY=(H_test' * bestweight)';

